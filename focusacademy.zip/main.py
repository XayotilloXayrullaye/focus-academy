import sys
import os
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, 
    QInputDialog, QLineEdit, QMessageBox
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtCore import QUrl, Qt, QObject, pyqtSlot

# --- JavaScript bilan aloqa qilish uchun klass ---
class Bridge(QObject):
    @pyqtSlot(str)
    def testFinished(self, result):
        print(f"Test yakunlandi. Natija: {result}")
        QMessageBox.information(None, "Focus Academy", f"Test yakunlandi! Natija: {result}")

class FocusAcademy(QMainWindow):
    def __init__(self):
        super().__init__()

        # 1. Kiosk Mode sozlamalari
        self.setWindowTitle("Focus Academy Launcher")
        
        # Frameless (chegarasiz) va har doim ustida turish (StaysOnTop)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | 
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Window
        )
        
        # To'liq ekran
        self.showFullScreen()

        # 2. Web brauzer komponenti
        self.browser = QWebEngineView()
        
        # JavaScript bilan aloqa (Bridge)
        self.channel = QWebChannel()
        self.bridge = Bridge()
        self.channel.registerObject("pyBridge", self.bridge)
        self.browser.page().setWebChannel(self.channel)

        # HTML faylni yuklash
        html_path = os.path.join(os.getcwd(), "test.html")
        if os.path.exists(html_path):
            self.browser.setUrl(QUrl.fromLocalFile(html_path))
        else:
            self.browser.setHtml("<h1>test.html fayli topilmadi!</h1>")

        # Markaziy vidjet
        self.setCentralWidget(self.browser)

    # 3. Bloklash mantiqi (Klaviatura tugmalari)
    def keyPressEvent(self, event):
        # Ctrl+Q bosilganda chiqish parolini so'rash
        if event.modifiers() == Qt.KeyboardModifier.ControlModifier and event.key() == Qt.Key.Key_Q:
            self.request_exit()
        
        # Boshqa tugmalarni bloklash (Escape va h.k.)
        elif event.key() == Qt.Key.Key_Escape:
            pass # Escape tugmasi hech narsa qilmaydi
        else:
            super().keyPressEvent(event)

    def request_exit(self):
        password, ok = QInputDialog.getText(
            self, "Chiqish", "Admin parolini kiriting:", 
            QLineEdit.EchoMode.Password
        )
        
        if ok and password == "admin123":
            QApplication.quit()
        elif ok:
            QMessageBox.warning(self, "Xato", "Parol noto'g'ri!")

    # Focus yo'qolganda (masalan Alt+Tab) qayta o'ziga tortish
    def changeEvent(self, event):
        if event.type() == event.Type.ActivationChange:
            if not self.isActiveWindow():
                self.activateWindow()
                self.raise_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FocusAcademy()
    window.show()
    sys.exit(app.exec())
