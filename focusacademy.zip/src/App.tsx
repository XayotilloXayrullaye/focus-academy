import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Lock, 
  Unlock, 
  BookOpen, 
  Headphones, 
  PenTool, 
  Mic, 
  Trophy, 
  AlertTriangle, 
  LogOut,
  ChevronRight,
  CheckCircle2,
  XCircle,
  Play,
  RotateCcw,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { cn } from '@/src/lib/utils';
import { 
  generateTask, 
  assessWriting, 
  assessSpeaking, 
  TaskContent, 
  AssessmentResult 
} from './services/geminiService';

// --- Types ---
type AppState = 'dashboard' | 'reading' | 'listening' | 'writing' | 'speaking' | 'result';

interface UserStats {
  tokens: number;
  completedTasks: number;
  currentLevel: string;
}

// --- Constants ---
const MASTER_PASSWORD = "focus_admin_2026";
const PASSING_SCORE = 80;

export default function App() {
  const [state, setState] = useState<AppState>('dashboard');
  const [isLocked, setIsLocked] = useState(false);
  const [stats, setStats] = useState<UserStats>({ tokens: 0, completedTasks: 0, currentLevel: 'Intermediate' });
  const [currentTask, setCurrentTask] = useState<TaskContent | null>(null);
  const [lastResult, setLastResult] = useState<AssessmentResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showExitModal, setShowExitModal] = useState(false);
  const [exitPassword, setExitPassword] = useState("");
  const [violations, setViolations] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);

  // --- Kiosk Mode Simulation ---
  const enterKiosk = useCallback(() => {
    if (containerRef.current?.requestFullscreen) {
      containerRef.current.requestFullscreen().catch(console.error);
    }
    setIsLocked(true);
  }, []);

  const exitKiosk = useCallback(() => {
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(console.error);
    }
    setIsLocked(false);
    setState('dashboard');
  }, []);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (isLocked && document.visibilityState === 'hidden') {
        setViolations(v => v + 1);
        alert("FocusAcademy: Boshqa tabga o'tish taqiqlangan! Topshiriqni yakunlang.");
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (isLocked) {
        // Prevent common exit keys if possible (limited in browser)
        if (e.key === 'Escape' && !showExitModal) {
          e.preventDefault();
          setShowExitModal(true);
        }
      }
    };

    window.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isLocked, showExitModal]);

  // --- Task Handlers ---
  const startTask = async (type: TaskContent['type']) => {
    setIsLoading(true);
    try {
      const task = await generateTask(type, stats.currentLevel);
      setCurrentTask(task);
      setState(type);
      enterKiosk();
    } catch (error) {
      console.error(error);
      alert("Xatolik yuz berdi. Qayta urinib ko'ring.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleTaskComplete = (result: AssessmentResult) => {
    setLastResult(result);
    if (result.passed) {
      setStats(prev => ({
        ...prev,
        tokens: prev.tokens + 10,
        completedTasks: prev.completedTasks + 1
      }));
    }
    setState('result');
  };

  const handleExitAttempt = () => {
    if (exitPassword === MASTER_PASSWORD) {
      exitKiosk();
      setShowExitModal(false);
      setExitPassword("");
    } else {
      alert("Noto'g'ri parol!");
    }
  };

  // --- Renderers ---
  return (
    <div 
      ref={containerRef}
      className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-orange-500/30"
    >
      {/* Header */}
      <header className="border-b border-white/10 p-6 flex justify-between items-center bg-black/50 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center shadow-lg shadow-orange-600/20">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">FocusAcademy</h1>
            <p className="text-xs text-white/50 uppercase tracking-widest">Intellektual O'quv Platformasi</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-full border border-white/10">
            <Trophy className="w-4 h-4 text-orange-500" />
            <span className="text-sm font-medium">{stats.tokens} Tokens</span>
          </div>
          {isLocked && (
            <button 
              onClick={() => setShowExitModal(true)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/50 hover:text-white"
            >
              <LogOut className="w-5 h-5" />
            </button>
          )}
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-8">
        <AnimatePresence mode="wait">
          {state === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <div className="text-center space-y-4 max-w-2xl mx-auto">
                <h2 className="text-4xl font-light tracking-tight">Xush kelibsiz, O'quvchi</h2>
                <p className="text-white/60 leading-relaxed">
                  Bugungi o'quv rejangiz tayyor. Topshiriqlarni muvaffaqiyatli bajarmaguningizcha 
                  tizimdan chiqish imkoniyati cheklangan bo'ladi.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <TaskCard 
                  title="Reading" 
                  desc="Matn tahlili va tushunish" 
                  icon={<BookOpen />} 
                  color="blue"
                  onClick={() => startTask('reading')}
                  disabled={isLoading}
                />
                <TaskCard 
                  title="Listening" 
                  desc="Audio tushunish va to'ldirish" 
                  icon={<Headphones />} 
                  color="purple"
                  onClick={() => startTask('listening')}
                  disabled={isLoading}
                />
                <TaskCard 
                  title="Writing" 
                  desc="Insho va AI tahlili" 
                  icon={<PenTool />} 
                  color="orange"
                  onClick={() => startTask('writing')}
                  disabled={isLoading}
                />
                <TaskCard 
                  title="Speaking" 
                  desc="Talaffuz va ravonlik" 
                  icon={<Mic />} 
                  color="emerald"
                  onClick={() => startTask('speaking')}
                  disabled={isLoading}
                />
              </div>

              {violations > 0 && (
                <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl flex items-center gap-4 text-red-400">
                  <AlertTriangle className="w-6 h-6 shrink-0" />
                  <p className="text-sm">
                    Diqqat: Sizda {violations} ta qoida buzilishi aniqlandi. 
                    Tizimdan chiqishga urinishlar qayd etilmoqda.
                  </p>
                </div>
              )}
            </motion.div>
          )}

          {(state === 'reading' || state === 'listening' || state === 'writing' || state === 'speaking') && currentTask && (
            <TaskModule 
              task={currentTask} 
              onComplete={handleTaskComplete} 
              onExit={() => setShowExitModal(true)}
            />
          )}

          {state === 'result' && lastResult && (
            <ResultView 
              result={lastResult} 
              onRetry={() => startTask(currentTask!.type)}
              onFinish={() => {
                if (lastResult.passed) exitKiosk();
                else startTask(currentTask!.type);
              }}
            />
          )}
        </AnimatePresence>
      </main>

      {/* Exit Modal */}
      <AnimatePresence>
        {showExitModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/80 backdrop-blur-xl"
              onClick={() => !isLocked && setShowExitModal(false)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-[#1a1a1a] border border-white/10 p-8 rounded-3xl max-w-md w-full shadow-2xl"
            >
              <div className="flex flex-col items-center text-center space-y-6">
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center">
                  <AlertTriangle className="w-8 h-8 text-red-500" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold">Favqulodda Chiqish</h3>
                  <p className="text-white/50 text-sm">
                    Tizimdan chiqish uchun "Master Password"ni kiriting. 
                    Bu faqat favqulodda holatlar uchun.
                  </p>
                </div>
                <input 
                  type="password"
                  value={exitPassword}
                  onChange={(e) => setExitPassword(e.target.value)}
                  placeholder="Asosiy parol..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500 transition-colors"
                />
                <div className="flex gap-3 w-full">
                  <button 
                    onClick={() => setShowExitModal(false)}
                    className="flex-1 px-6 py-3 rounded-xl border border-white/10 hover:bg-white/5 transition-colors"
                  >
                    Bekor qilish
                  </button>
                  <button 
                    onClick={handleExitAttempt}
                    className="flex-1 px-6 py-3 rounded-xl bg-orange-600 hover:bg-orange-500 font-bold transition-colors"
                  >
                    Tasdiqlash
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {isLoading && (
        <div className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-sm flex items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-orange-500 font-medium animate-pulse">AI topshiriq tayyorlamoqda...</p>
          </div>
        </div>
      )}
    </div>
  );
}

// --- Sub-components ---

function TaskCard({ title, desc, icon, color, onClick, disabled }: any) {
  const colors: any = {
    blue: "hover:border-blue-500/50 hover:bg-blue-500/5",
    purple: "hover:border-purple-500/50 hover:bg-purple-500/5",
    orange: "hover:border-orange-500/50 hover:bg-orange-500/5",
    emerald: "hover:border-emerald-500/50 hover:bg-emerald-500/5",
  };

  const iconColors: any = {
    blue: "bg-blue-500/20 text-blue-400",
    purple: "bg-purple-500/20 text-purple-400",
    orange: "bg-orange-500/20 text-orange-400",
    emerald: "bg-emerald-500/20 text-emerald-400",
  };

  return (
    <button 
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "group p-8 rounded-[2rem] border border-white/5 bg-white/[0.02] text-left transition-all duration-500",
        colors[color],
        disabled && "opacity-50 cursor-not-allowed"
      )}
    >
      <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-transform group-hover:scale-110", iconColors[color])}>
        {React.cloneElement(icon, { className: "w-7 h-7" })}
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-sm text-white/40 leading-relaxed">{desc}</p>
      <div className="mt-8 flex items-center gap-2 text-xs font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
        Boshlash <ChevronRight className="w-4 h-4" />
      </div>
    </button>
  );
}

function TaskModule({ task, onComplete, onExit }: { task: TaskContent, onComplete: (res: AssessmentResult) => void, onExit: () => void }) {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [writingContent, setWritingContent] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [timeLeft, setTimeLeft] = useState(task.type === 'reading' ? 600 : 0);
  const [playCount, setPlayCount] = useState(0);
  const [isAssessing, setIsAssessing] = useState(false);

  useEffect(() => {
    if (task.type === 'reading' && timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
      return () => clearInterval(timer);
    }
  }, [task.type, timeLeft]);

  const handleSubmit = async () => {
    setIsAssessing(true);
    try {
      let result: AssessmentResult;

      if (task.type === 'reading' || task.type === 'listening') {
        let correct = 0;
        task.questions?.forEach(q => {
          if (answers[q.id]?.toLowerCase() === q.correctAnswer.toLowerCase()) correct++;
        });
        const score = (correct / (task.questions?.length || 1)) * 100;
        result = {
          score,
          passed: score >= PASSING_SCORE,
          feedback: score >= PASSING_SCORE ? "Ajoyib natija!" : "Natija yetarli emas. Qayta urinib ko'ring.",
          errors: task.questions?.filter(q => answers[q.id]?.toLowerCase() !== q.correctAnswer.toLowerCase()).map(q => q.question)
        };
      } else if (task.type === 'writing') {
        result = await assessWriting(task.content, writingContent);
      } else {
        result = await assessSpeaking(task.content, transcript);
      }

      onComplete(result);
    } catch (error) {
      console.error(error);
      alert("Tahlil qilishda xatolik.");
    } finally {
      setIsAssessing(false);
    }
  };

  const speak = (text: string) => {
    if (playCount >= 2) {
      alert("Audioni faqat 2 marta eshitish mumkin!");
      return;
    }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    window.speechSynthesis.speak(utterance);
    setPlayCount(p => p + 1);
  };

  const startRecording = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Brauzeringiz ovozni aniqlashni qo'llab-quvvatlamaydi.");
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsRecording(true);
    recognition.onresult = (event: any) => {
      let current = "";
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        current += event.results[i][0].transcript;
      }
      setTranscript(current);
    };
    recognition.onend = () => setIsRecording(false);
    recognition.start();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-[#111] border border-white/10 rounded-[2.5rem] overflow-hidden shadow-2xl"
    >
      <div className="p-8 border-b border-white/5 flex justify-between items-center bg-white/[0.02]">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center">
            {task.type === 'reading' && <BookOpen className="text-blue-400" />}
            {task.type === 'listening' && <Headphones className="text-purple-400" />}
            {task.type === 'writing' && <PenTool className="text-orange-400" />}
            {task.type === 'speaking' && <Mic className="text-emerald-400" />}
          </div>
          <div>
            <h2 className="text-2xl font-bold">{task.title}</h2>
            <p className="text-xs text-white/40 uppercase tracking-widest">{task.type} Module</p>
          </div>
        </div>
        
        {task.type === 'reading' && (
          <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-xl border border-white/10">
            <Clock className="w-4 h-4 text-orange-500" />
            <span className={cn("font-mono font-bold", timeLeft < 60 ? "text-red-500 animate-pulse" : "text-white")}>
              {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
            </span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 h-[70vh]">
        {/* Content Side */}
        <div className="p-10 overflow-y-auto border-r border-white/5 bg-black/20">
          {task.type === 'reading' && (
            <div className="prose prose-invert max-w-none">
              <Markdown>{task.content}</Markdown>
            </div>
          )}
          {task.type === 'listening' && (
            <div className="flex flex-col items-center justify-center h-full space-y-8 text-center">
              <div className="w-32 h-32 bg-purple-500/10 rounded-full flex items-center justify-center border border-purple-500/20">
                <Headphones className="w-12 h-12 text-purple-500" />
              </div>
              <div className="space-y-4">
                <h3 className="text-2xl font-light">Audioni diqqat bilan eshiting</h3>
                <p className="text-white/40 max-w-xs mx-auto">Sizda audioni faqat 2 marta eshitish imkoniyati bor.</p>
              </div>
              <button 
                onClick={() => speak(task.content)}
                disabled={playCount >= 2}
                className="flex items-center gap-3 px-8 py-4 bg-purple-600 hover:bg-purple-500 rounded-2xl font-bold transition-all disabled:opacity-50 disabled:bg-white/10"
              >
                <Play className="w-5 h-5" /> 
                {playCount === 0 ? "Audioni tinglash" : playCount === 1 ? "Oxirgi marta eshitish" : "Imkoniyat tugadi"}
              </button>
            </div>
          )}
          {task.type === 'writing' && (
            <div className="space-y-6">
              <div className="p-6 bg-orange-500/5 border border-orange-500/20 rounded-2xl">
                <h4 className="text-orange-500 font-bold uppercase text-xs tracking-widest mb-2">Prompt</h4>
                <p className="text-lg leading-relaxed">{task.content}</p>
              </div>
              <div className="text-sm text-white/40">
                <p>• Kamida 150 ta so'z yozing.</p>
                <p>• Grammatika va punktuatsiyaga e'tibor bering.</p>
                <p>• Mavzudan chetlashmang.</p>
              </div>
            </div>
          )}
          {task.type === 'speaking' && (
            <div className="flex flex-col items-center justify-center h-full space-y-8 text-center">
              <div className="w-32 h-32 bg-emerald-500/10 rounded-full flex items-center justify-center border border-emerald-500/20">
                <Mic className="w-12 h-12 text-emerald-500" />
              </div>
              <div className="space-y-4">
                <h3 className="text-2xl font-light">{task.content}</h3>
                <p className="text-white/40 max-w-xs mx-auto">Savolga ingliz tilida javob bering. AI talaffuz va ravonlikni tekshiradi.</p>
              </div>
            </div>
          )}
        </div>

        {/* Interaction Side */}
        <div className="p-10 overflow-y-auto flex flex-col">
          <div className="flex-1 space-y-8">
            {(task.type === 'reading' || task.type === 'listening') && task.questions?.map((q, idx) => (
              <div key={q.id} className="space-y-4">
                <p className="font-medium text-lg"><span className="text-white/30 mr-2">{idx + 1}.</span> {q.question}</p>
                {q.options ? (
                  <div className="grid grid-cols-1 gap-3">
                    {q.options.map(opt => (
                      <button
                        key={opt}
                        onClick={() => setAnswers(prev => ({ ...prev, [q.id]: opt }))}
                        className={cn(
                          "p-4 rounded-xl border text-left transition-all",
                          answers[q.id] === opt 
                            ? "bg-orange-600 border-orange-500 shadow-lg shadow-orange-600/20" 
                            : "bg-white/5 border-white/10 hover:bg-white/10"
                        )}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                ) : (
                  <input 
                    type="text"
                    placeholder="Javobingizni kiriting..."
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-orange-500"
                    onChange={(e) => setAnswers(prev => ({ ...prev, [q.id]: e.target.value }))}
                  />
                )}
              </div>
            ))}

            {task.type === 'writing' && (
              <textarea 
                value={writingContent}
                onChange={(e) => setWritingContent(e.target.value)}
                placeholder="Inshoni shu yerga yozing..."
                className="w-full h-full min-h-[400px] bg-white/5 border border-white/10 rounded-3xl p-8 focus:outline-none focus:border-orange-500 resize-none leading-relaxed"
              />
            )}

            {task.type === 'speaking' && (
              <div className="flex flex-col items-center justify-center h-full space-y-6">
                <div className="w-full p-8 bg-white/5 border border-white/10 rounded-3xl min-h-[200px] flex items-center justify-center text-center">
                  <p className={cn("text-lg", !transcript && "text-white/20 italic")}>
                    {transcript || "Gapirishni boshlash uchun tugmani bosing..."}
                  </p>
                </div>
                <button 
                  onClick={isRecording ? () => setIsRecording(false) : startRecording}
                  className={cn(
                    "w-20 h-20 rounded-full flex items-center justify-center transition-all duration-500",
                    isRecording 
                      ? "bg-red-500 animate-pulse scale-110 shadow-lg shadow-red-500/50" 
                      : "bg-emerald-600 hover:bg-emerald-500"
                  )}
                >
                  <Mic className="w-8 h-8" />
                </button>
                <p className="text-xs uppercase tracking-widest text-white/40">
                  {isRecording ? "Yozib olinmoqda..." : "Mikrofonni yoqing"}
                </p>
              </div>
            )}
          </div>

          <div className="mt-10 pt-8 border-t border-white/5">
            <button 
              onClick={handleSubmit}
              disabled={isAssessing}
              className="w-full py-5 bg-orange-600 hover:bg-orange-500 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-3 shadow-xl shadow-orange-600/20 disabled:opacity-50"
            >
              {isAssessing ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  AI Tahlil qilmoqda...
                </>
              ) : (
                <>Topshiriqni yakunlash <ChevronRight className="w-5 h-5" /></>
              )}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function ResultView({ result, onRetry, onFinish }: { result: AssessmentResult, onRetry: () => void, onFinish: () => void }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-3xl mx-auto space-y-8"
    >
      <div className={cn(
        "p-12 rounded-[3rem] border text-center space-y-6 shadow-2xl",
        result.passed ? "bg-emerald-500/10 border-emerald-500/20" : "bg-red-500/10 border-red-500/20"
      )}>
        <div className={cn(
          "w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-4",
          result.passed ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"
        )}>
          {result.passed ? <CheckCircle2 className="w-12 h-12" /> : <XCircle className="w-12 h-12" />}
        </div>
        
        <div className="space-y-2">
          <h2 className="text-5xl font-black tracking-tighter">{result.score}%</h2>
          <p className="text-xl font-medium">{result.passed ? "Muvaffaqiyatli!" : "Yetersiz natija"}</p>
        </div>

        <div className="bg-black/20 p-8 rounded-3xl text-left border border-white/5">
          <h4 className="text-xs font-bold uppercase tracking-widest text-white/40 mb-4">AI Feedback</h4>
          <div className="prose prose-invert prose-sm max-w-none">
            <Markdown>{result.feedback}</Markdown>
          </div>
        </div>

        {result.errors && result.errors.length > 0 && (
          <div className="text-left space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-red-400/60">Xatolar tahlili</h4>
            <ul className="space-y-2">
              {result.errors.map((err, i) => (
                <li key={i} className="text-sm text-white/60 flex gap-3">
                  <span className="text-red-500 shrink-0">•</span> {err}
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="flex gap-4 pt-4">
          {!result.passed ? (
            <button 
              onClick={onRetry}
              className="flex-1 py-5 bg-red-600 hover:bg-red-500 rounded-2xl font-bold transition-all flex items-center justify-center gap-3"
            >
              <RotateCcw className="w-5 h-5" /> Qayta urinish
            </button>
          ) : (
            <button 
              onClick={onFinish}
              className="flex-1 py-5 bg-emerald-600 hover:bg-emerald-500 rounded-2xl font-bold transition-all flex items-center justify-center gap-3"
            >
              Dashboardga qaytish <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {result.passed && (
        <div className="bg-orange-500/10 border border-orange-500/20 p-8 rounded-[2rem] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-orange-500/20 rounded-2xl flex items-center justify-center">
              <Trophy className="text-orange-500" />
            </div>
            <div>
              <h4 className="font-bold">+10 Entertainment Tokens</h4>
              <p className="text-sm text-white/40">Muvaffaqiyatli topshiriq uchun mukofot!</p>
            </div>
          </div>
          <div className="text-2xl font-black text-orange-500">10</div>
        </div>
      )}
    </motion.div>
  );
}
