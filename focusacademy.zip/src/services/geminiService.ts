import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface TaskContent {
  id: string;
  type: 'reading' | 'listening' | 'writing' | 'speaking';
  title: string;
  content: string; // Text for reading, audio script for listening, prompt for writing/speaking
  questions?: {
    id: string;
    question: string;
    options?: string[];
    correctAnswer: string;
  }[];
  audioUrl?: string;
}

export interface AssessmentResult {
  score: number;
  feedback: string;
  passed: boolean;
  errors?: string[];
}

export const generateTask = async (type: TaskContent['type'], level: string = 'intermediate'): Promise<TaskContent> => {
  const prompt = `Generate a ${level} level ${type} task for an English learner. 
  Return JSON format.
  If reading: include a 300-word text and 5 multiple choice questions.
  If listening: include a dialogue script (I will use TTS) and 5 fill-in-the-blank questions.
  If writing: include an essay prompt.
  If speaking: include a discussion question.
  
  Schema:
  {
    "title": "string",
    "content": "string",
    "questions": [{"id": "string", "question": "string", "options": ["string"], "correctAnswer": "string"}]
  }`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
    }
  });

  try {
    const data = JSON.parse(response.text || "{}");
    return {
      id: Math.random().toString(36).substr(2, 9),
      type,
      ...data
    };
  } catch (e) {
    console.error("JSON Parse Error:", e, response.text);
    throw new Error("AI response format error");
  }
};

export const assessWriting = async (prompt: string, essay: string): Promise<AssessmentResult> => {
  const assessmentPrompt = `Assess the following essay based on the prompt: "${prompt}".
  Essay: "${essay}"
  Provide a score out of 100, detailed feedback on grammar and content, and a list of specific errors.
  Return JSON: { "score": number, "feedback": "string", "errors": ["string"] }`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: assessmentPrompt,
    config: {
      responseMimeType: "application/json",
    }
  });

  try {
    const data = JSON.parse(response.text || "{}");
    return {
      ...data,
      passed: (data.score || 0) >= 80
    };
  } catch (e) {
    console.error("JSON Parse Error:", e, response.text);
    return { score: 0, feedback: "Tahlil qilishda xatolik yuz berdi.", passed: false, errors: ["AI format error"] };
  }
};

export const assessSpeaking = async (question: string, transcript: string): Promise<AssessmentResult> => {
  const assessmentPrompt = `Assess the following spoken response transcript based on the question: "${question}".
  Transcript: "${transcript}"
  Provide a score out of 100, feedback on pronunciation (based on transcript clues if any), fluency, and grammar.
  Return JSON: { "score": number, "feedback": "string", "errors": ["string"] }`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: assessmentPrompt,
    config: {
      responseMimeType: "application/json",
    }
  });

  try {
    const data = JSON.parse(response.text || "{}");
    return {
      ...data,
      passed: (data.score || 0) >= 80
    };
  } catch (e) {
    console.error("JSON Parse Error:", e, response.text);
    return { score: 0, feedback: "Tahlil qilishda xatolik yuz berdi.", passed: false, errors: ["AI format error"] };
  }
};
