# Focus Academy: Secure Kiosk Mode Launcher

Ushbu loyiha Python va PyQt6 yordamida yaratilgan bo'lib, o'quvchilar uchun xavfsiz test muhitini ta'minlaydi.

## 🛠 O'rnatish (Local Kompyuterda)

Dasturni ishga tushirish uchun kompyuteringizda Python o'rnatilgan bo'lishi kerak.

1. Kerakli kutubxonalarni o'rnating:
   ```bash
   pip install PyQt6 PyQt6-WebEngine
   ```

2. Loyiha fayllarini bitta papkaga joylashtiring:
   - `main.py`
   - `test.html`

3. Dasturni ishga tushiring:
   ```bash
   python main.py
   ```

## 📦 .EXE Faylga Aylantirish (PyInstaller)

Dasturni bitta mustaqil `.exe` fayliga aylantirish uchun quyidagi amallarni bajaring:

1. PyInstaller-ni o'rnating:
   ```bash
   pip install pyinstaller
   ```

2. Quyidagi buyruqni terminalda (loyiha papkasida) ishga tushiring:
   ```bash
   pyinstaller --noconsole --onefile --add-data "test.html;." main.py
   ```

   *Tushuntirish:*
   - `--noconsole`: Dastur ochilganda orqada qora terminal oynasi chiqmaydi.
   - `--onefile`: Barcha kutubxonalarni bitta `.exe` ichiga jamlaydi.
   - `--add-data "test.html;."`: HTML faylni dastur ichiga qo'shadi.

3. Tayyor fayl `dist` papkasida paydo bo'ladi.

## 🔐 Xavfsizlik Funksiyalari

- **To'liq ekran:** Dastur butun ekranni egallaydi va chegarasiz (borderless).
- **Stays On Top:** Boshqa oynalar Focus Academy ustiga chiqa olmaydi.
- **Ctrl+Q:** Faqat shu kombinatsiya orqali chiqish mumkin (Parol: `admin123`).
- **JS Bridge:** HTML ichidagi natijalar Python-ga xavfsiz uzatiladi.
- **Context Menu:** Sichqonchaning o'ng tugmasi taqiqlangan.
